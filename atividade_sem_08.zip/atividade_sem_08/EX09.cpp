#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 9 � Controle Ambiental

Um sistema monitora temperaturas ao longo do dia.
Valores registrados: [30, 32, 28, 27, 35]

Verifique usando busca sequencial se houve registro de 27�C
*/

void buscaSequencial(int vetor[], int tam, int temp){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == temp){
			printf("Houve registro de %d graus", temp);
			return;
		}
	}
	printf("Sem registro com a temperatura %d graus", temp);
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int temperaturas[] = {30, 32, 28, 27, 35};
	int tamanho = sizeof(temperaturas) / sizeof(temperaturas[0]);
	
	int busca_temp = 27;
	
	buscaSequencial(temperaturas, tamanho, busca_temp);
}
