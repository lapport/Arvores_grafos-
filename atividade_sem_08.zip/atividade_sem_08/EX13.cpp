#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 13 � Sistema Meteorol�gico

Um sistema analisa temperaturas hist�ricas para gerar relat�rios.
Dados: [33, 29, 31, 30, 28]

1. Ordene os valores
2. Verifique com busca bin�ria se 31�C foi registrado 
*/

void ordenarVetor(int vetor[], int tam){

	int i, j, key;
	
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j+1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
		
	}
	printf("VETOR ORDENADO\n");
}

void buscaBinaria(int vetor[],int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Temperatura %d encontrada", busca);
			return;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Temperatura %d n�o encontrada", busca);
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int temperaturas[] = {33, 29, 31, 30, 28};
	int tamanho = sizeof(temperaturas) / sizeof(temperaturas[0]);
	
	int busca_temp = 31;
	
	ordenarVetor(temperaturas, tamanho);
	
	buscaBinaria(temperaturas, tamanho, busca_temp);
}

