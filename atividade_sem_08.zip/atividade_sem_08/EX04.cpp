#include<stdio.h>
#include<locale.h>
#include<string.h>

/*
Exerc�cio 4 � Controle de Acesso em Evento

Na entrada de um evento, um sistema valida os nomes dos convidados antes de permitir o
acesso.

Lista de convidados: ["Ana", "Bruno", "Carlos", "Diana"]

Verifique usando busca sequencial se "Diana" est� autorizada a entrar.
� Retorne a posi��o na lista 
*/

int buscaSequencial(char *vetor[], int tam, char *nome){
	for(int i = 0 ; i < tam; i++){
		if(strcmp(vetor[i], nome) == 0){
			printf("Nome esta na lista\n");
			return i;
		}
	}
	printf("O nome nao esta na lista");
	return -1;
}

int main(){
	setlocale(LC_ALL, "Portuguese");

	char *nomes[4] = {"Ana", "Bruno", "Carlos", "Diana"}; 
	
	int tamanho = sizeof(nomes) / sizeof(nomes[0]);
	
	char *busca_nome = "Diana";
	
	int pos = buscaSequencial(nomes, tamanho, busca_nome);
	
	printf("%s esta na posi�ao %d da lista", busca_nome, pos);
}
