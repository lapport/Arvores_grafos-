#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 11 � Sistema de Biblioteca

Uma biblioteca digital precisa acelerar a busca por livros, pois o volume de dados aumentou.
IDs cadastrados (desordenados): [45, 12, 78, 34, 23]

Para otimizar:
1. Ordene os dados
2. Verifique usando busca bin�ria se o livro 34 existe
3. Informe a posi��o no vetor ordenado
 */


void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
	}
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda)/2;
		
		if(vetor[meio] == busca){
			printf("Valor encontrado\n");
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor nao encontrado");
	return -1;
}



int main(){
	setlocale(LC_ALL,"Portuguese");
	
	int id[] = {45, 12, 78, 34, 23};
	int tamanho = sizeof(id) / sizeof(id[0]);
	
	int busca_livro = 34;
	
	ordenarVetor(id, tamanho);
	
	int pos = buscaBinaria(id, tamanho, busca_livro);
	
	printf("Valor na posi��o %d",pos);

}
