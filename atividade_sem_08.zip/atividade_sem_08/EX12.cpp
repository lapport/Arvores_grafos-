#include<stdio.h>
#include<locale.h>

/*
Um sistema de ranking precisa localizar rapidamente a posi��o de um jogador.

Pontua��es registradas: [500, 200, 800, 300, 100]

1. Ordene o ranking
2. Busque 300 usando busca bin�ria
3. Informe posi��o e n�mero de compara��es 

*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	
	for(i = 1 ; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca, int *contador){
	int esquerda = 0;
	int direita = tam - 1;
	*contador = 0;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		(*contador)++;
		if(vetor[meio] == busca){
			return meio;
		}
		
		(*contador)++;
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	return -1;
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int pontuacoes[] = {500, 200, 800, 300, 100};
	int tamanho = sizeof(pontuacoes) / sizeof(pontuacoes[0]);
	
	int busca_pont = 300;
	int contador;
	
	ordenarVetor(pontuacoes, tamanho);
	
	int pos = buscaBinaria(pontuacoes, tamanho, busca_pont, &contador);
	printf("Quantidade de compara��es: %d \n", contador);
	printf("Posi��o no vetor: %d", pos);
	
}
