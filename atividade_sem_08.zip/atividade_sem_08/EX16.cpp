#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 16 � Central de Atendimento

Uma empresa precisa localizar rapidamente um chamado espec�fico entre v�rios registros.
IDs: [900, 850, 920, 870, 880]

1. Ordene
2. Busque 870 com busca bin�ria

*/


void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
	}
	printf("o que � a vida?(vetor ordenado)\n");
}
/*
void sequencial(int vetor[], int tam, int busca){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == busca){
			printf("ACHOU");   escrevi o sequencial dnv pq achei q n lembrava....
		}
	}
	printf("N ACHOU");
}
*/

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("A gnose foi atingida em %d \n", busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("A gnose nao foi atingida\n");
	return -1;
}

int main(){
	setlocale(LC_ALL,"Portuguese");
	
	int chamados[] = {900, 850, 920, 870, 880};
	int tamanho = sizeof(chamados) / sizeof(chamados[0]);
	
	int busca = 870;
	
	ordenarVetor(chamados, tamanho);
	
	int pos = buscaBinaria(chamados, tamanho, busca);
	printf("A gnose foi atingida na posi�ao %d", pos);
}
