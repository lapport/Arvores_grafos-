#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 10 � Valida��o de Cadastro

Antes de cadastrar um novo funcion�rio, o sistema precisa evitar duplicidade.

IDs existentes: [2001, 2002, 2003, 2004]

Verifique usando busca sequencial se o ID 2005 j� est� cadastrado.
*/

void buscaSequencial(int vetor[], int tam, int id){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == id){
			printf("O ID de numero %d foi encontrado", id);
			return;
		}
	}
	printf("ID %d n�o encontrado",id);
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int id[] = {2001, 2002, 2003, 2004};
	int tamanho = sizeof(id) / sizeof(id[0]);
	
	int busca_id = 2005;
	
	buscaSequencial(id, tamanho, busca_id);
}
