#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 29 � Sistema de Busca Configur�vel

Uma aplica��o permite escolher o tipo de busca conforme necessidade.
Implemente:
� Busca sequencial
� Busca bin�ria
E permita ao usu�rio escolher qual usar.

*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	ordenarVetor(vetor, tam);
	int esquerda = 0;
	int direita = tam - 1;
	int comp = 0;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		comp++;
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return comp;
		}
		comp++;
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}

int buscaSequencial(int vetor[],int tam,int busca){
	int comp = 0;
	for(int i = 0; i < tam; i++){
		comp++;
		if(vetor[i] == busca){
			return comp;
		}
	}
	return -1;
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int dados[] = {64, 21, 33, 70, 12, 85, 50};
	int tamanho = sizeof(dados) / sizeof(dados[0]);
	int opc;
	int busca;
	
	printf("1 - Sequencial\n");
	printf("2 - Binaria\n");
	
	printf("Escolha uma op�ao: ");
	scanf("%d", &opc);
	
	if(opc == 1){
		printf("digite a busca: ");
		scanf("%d", &busca);
		buscaSequencial(dados, tamanho, busca);
	}else{
		printf("digite a busca: ");
		scanf("%d", &busca);
		buscaBinaria(dados, tamanho, busca);
	}



	
}

