#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 17 � Monitoramento de Sa�de

Um sistema hospitalar analisa dados de pacientes.
Frequ�ncias card�acas: [72, 80, 65, 90, 75]

1. Ordene
2. Verifique se 65 foi registrado usando busca bin�ria 
*/


void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j+1] = key;
	}
	printf("!ODANEDRO ROTEV\n");
}

void buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("!ODARTNOCNE %d ROLAV ", busca);
			return;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
		
	}
	printf("ODARTNOCNE OAN ROLAV");
}

int main(){
	setlocale(LC_ALL,"Portuguese");
	
	int frequencia[] = {72, 80, 65, 90, 75};
	int tamanho = sizeof(frequencia) / sizeof(frequencia[0]);
	
	int busca = 65;
	
	ordenarVetor(frequencia, tamanho);
	
	buscaBinaria(frequencia, tamanho, busca);	
}
