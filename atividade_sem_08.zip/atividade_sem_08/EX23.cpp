#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 23 � Monitoramento de Rede

Uma equipe de TI analisa desempenho de rede.
Lat�ncias: [120, 80, 200, 60, 150]
1. Ordene
2. Busque 60ms
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int sensores[] = {120, 80, 200, 60, 150};
	int tamanho = sizeof(sensores) / sizeof(sensores[0]);
	
	int busca = 60;
	
	ordenarVetor(sensores, tamanho);
	
	int pos = buscaBinaria(sensores, tamanho, busca);
	printf("Valor %d encontrado na posi��o %d", busca, pos);
	
}

