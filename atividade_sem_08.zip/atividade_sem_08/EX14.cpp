#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 14 � Plataforma de Vendas



Uma plataforma precisa verificar rapidamente se uma venda espec�fica foi registrada.
Valores: [150, 90, 200, 120, 300]

1. Ordene os dados
2. Busque 120 usando busca bin�ria 

*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
		
	}
}


void buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while (esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("O valor %d foi encontrado",busca);
			return;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;	
		}else{
			direita = meio - 1;
		}
	}
	printf("O valor %d nao foi encontrado", busca);
	
		
	
}


int main(){
	setlocale(LC_ALL,"Portuguese");
	
	int vendas[] = {150, 90, 200, 120, 300};
	int tamanho = sizeof(vendas) / sizeof(vendas[0]);
	
	int busca_venda = 120;
	
	ordenarVetor(vendas, tamanho);
	
	buscaBinaria(vendas, tamanho, busca_venda);
	
}
