#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 26 � Sistema Industrial

Sensores monitoram m�quinas em tempo real.
Dados: [45, 60, 30, 80, 55, 70]
1. Ordene
2. Busque 55
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int dados[] = {45, 60, 30, 80, 55, 70};
	int tamanho = sizeof(dados) / sizeof(dados[0]);
	
	int busca = 55;
	
	ordenarVetor(dados, tamanho);
	
	int pos = buscaBinaria(dados, tamanho, busca);
	printf("Valor %d encontrado na posi��o %d", busca, pos);
	
}

