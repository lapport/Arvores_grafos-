#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 5 � Auditoria de Notas

Um coordenador deseja verificar se algum aluno atingiu a nota m�xima em uma avalia��o.

Notas registradas: [7, 8, 5, 9, 6]

Verifique usando busca sequencial se existe nota 10.
� Informe claramente o resultado 

*/


int buscaSequencial(int vetor[], int tam, int nota){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == nota){
			printf("Aluno com nota 10 encontrado");
			return i;
		}
	}
	printf("nenhum aluno tirou nota maxima");
	return -1;
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int notas[] = {7,8,5,9,6};
	int tamanho = sizeof(notas) / sizeof(notas[0]);
	
	int busca_nota = 10;
	
	int pos = buscaSequencial(notas, tamanho, busca_nota);
	
}
