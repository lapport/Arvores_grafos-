#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 3 � Falta de Produto no Sistema

Um cliente solicitou um item que pode n�o estar cadastrado no sistema.

Lista de produtos dispon�veis: [5, 10, 15, 20]
Verifique usando busca sequencial se o produto 8 existe.
� Caso n�o exista, exiba uma mensagem de erro amig�vel ao usu�rio 
*/

int buscaSequencial(int vetor[], int tam, int codigo){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == codigo){
			printf("Valor encontrado\n");
			return i;
		}
	}
	printf("Valor nao encontrado!");
	return -1;
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	int produtos[] = {5, 10, 15, 20};
	int tamanho = sizeof(produtos) / sizeof(produtos[0]);
	
	int codigo = 8;
	
	int pos = buscaSequencial(produtos, tamanho, codigo);
	
}
