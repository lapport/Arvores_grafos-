#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 22 � Sistema Banc�rio

Um banco precisa verificar rapidamente contas com determinado saldo.
Saldos: [1500, 2300, 800, 1200, 2000]
1. Ordene
2. Busque 800
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	ordenarVetor(vetor, tam);
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int sensores[] = {1500, 2300, 800, 1200, 2000};
	int tamanho = sizeof(sensores) / sizeof(sensores[0]);
	
	int busca = 800;
	
	
	int pos = buscaBinaria(sensores, tamanho, busca);
	printf("Valor %d encontrado na posi��o %d", busca, pos);
	
}

