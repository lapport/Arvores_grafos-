#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 27 � Cat�logo de Produtos

Um sistema de marketplace precisa localizar produtos rapidamente.
IDs: [9001, 9005, 9002, 9008, 9003]
1. Ordene
2. Busque 9008
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int dados[] = {9001, 9005, 9002, 9008, 9003};
	int tamanho = sizeof(dados) / sizeof(dados[0]);
	
	int busca = 9008;
	
	ordenarVetor(dados, tamanho);
	
	int pos = buscaBinaria(dados, tamanho, busca);
	printf("Valor %d encontrado na posi��o %d", busca, pos);
	
}

