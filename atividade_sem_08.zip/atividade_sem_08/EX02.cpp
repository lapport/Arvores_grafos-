#include<stdio.h>

/*
Exerc�cio 2 � Confer�ncia de Mercadoria

Um operador log�stico recebe uma carga e precisa conferir rapidamente se um determinado
produto foi entregue.

C�digos recebidos: [12, 25, 30, 48, 50]

O sistema deve verificar se o produto 30 est� na lista.

Utilize busca sequencial e:
� Retorne a posi��o
� Informe o resultado da busca 
*/

int buscaSequencial(int vetor[], int tam, int codigo){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == codigo){
			printf("Produto localizado\n");
			return i;
		}
	}
	printf("Produto nao encontrado");
	return -1;
}


int main(){
	int produto[] = {12, 25, 30, 48, 50};
	int tamanho = sizeof(produto) / sizeof(produto[0]);
	
	int codigo = 30;
	
	int pos = buscaSequencial(produto, tamanho, codigo);
	if(pos != -1){
		printf("Produto encontrado na posicao %d", pos);
	}
	
}
