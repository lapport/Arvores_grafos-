#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 24 � An�lise de Algoritmos

Uma equipe quer decidir qual algoritmo usar em produ��o.
Dados: [64, 21, 33, 70, 12, 85, 50]
1. Busque 50 com busca sequencial
2. Ordene os dados
3. Busque com busca bin�ria
4. Compare desempenho e justifique 
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	int comp = 0;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		comp++;
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return comp;
		}
		comp++;
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}

int buscaSequencial(int vetor[],int tam,int busca){
	int comp = 0;
	for(int i = 0; i < tam; i++){
		comp++;
		if(vetor[i] == busca){
			return comp;
		}
	}
	return -1;
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int dados[] = {64, 21, 33, 70, 12, 85, 50};
	int tamanho = sizeof(dados) / sizeof(dados[0]);

	
	int busca = 50;
	
	int compSeq = buscaSequencial(dados, tamanho, busca);
	
	ordenarVetor(dados, tamanho);
	
	int compBin = buscaBinaria(dados, tamanho, busca);

	printf("Compara�oes da busca sequencial: %d\n", compSeq);
	printf("Compara�oes da busca binaria: %d",compBin);
	
}

