#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 15 � Cat�logo de E-commerce

Para melhorar o desempenho da busca, o sistema reorganiza os dados.
Produtos: [1010, 1002, 1005, 1001, 1008]

1. Ordene
2. Localize 1005 usando busca bin�ria 
*/


void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		
		vetor[j + 1] = key;
	}
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("NAO AGUENTO MAIS REPETIR O MESMO CODIGO HAHAHAHA, mas pelo menos aprendi");
	return -1;
}



int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int dados[] = {1010, 1002, 1005, 1001, 1008};
	int tamanho = sizeof(dados) / sizeof(dados[0]);
	
	int busca_dados = 1005;
	
	ordenarVetor(dados, tamanho);
	
	int pos = buscaBinaria(dados, tamanho, busca_dados);
	printf("Na posi��o %d",pos);
}

