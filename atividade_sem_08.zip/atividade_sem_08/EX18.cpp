#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 18 � Sistema Interativo de Dados

Um sistema recebe dados digitados pelo usu�rio em tempo real.

Requisitos:
1. Receber 10 n�meros
2. Ordenar os dados
3. Permitir busca com busca bin�ria 

*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
	printf("VETOR ORDENADO\n");
}

int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("Valor %d encontrado\n",busca);
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor %d n�o encontrado", busca);
}

int main(){
	setlocale(LC_ALL, "Portuguese");

	int tamanho = 10;
	int vetor[tamanho];
	int busca;

	for(int i = 0; i < tamanho; i++){
		printf("Digite numero da posi�ao %d: ",i);
		scanf("%d",&vetor[i]);
	}
	
	ordenarVetor(vetor, tamanho);
	
	printf("Qual numero deseja buscar ?");
	scanf("%d", &busca);
	
	int pos = buscaBinaria(vetor, tamanho, busca);
	
	if(pos != -1){
		printf("Na posi��o %d", pos);
	}
}

