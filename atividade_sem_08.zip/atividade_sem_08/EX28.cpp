#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 28 � Sistema de Avalia��o Acad�mica

Um professor deseja automatizar a an�lise de notas.
Requisitos:
1. Receber 15 notas
2. Ordenar
3. Buscar uma nota espec�fica
4. Informar posi��o e compara��es 
*/

int buscaBinaria(int vetor[], int tam, int busca, int *comp){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		(*comp)++;	
		if(vetor[meio] == busca){
			return meio;
		}
		(*comp)++;
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
}

void ordenarVetor(int vetor[],  int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
	}
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	int tamanho = 5;
	int dados[tamanho];
	int comp = 0, busca;
	
	for(int i = 0; i < tamanho; i++){
		printf("Digite o elemento %d: ", i);
		scanf("%d",&dados[i]);
	}
	ordenarVetor(dados, tamanho);
	
	printf("Nota a ser buscada: ");
	scanf("%d", &busca);
	
	int pos = buscaBinaria(dados, tamanho, busca, &comp);
	
	printf("Nota esta na posi�ao %d e foram feitas %d compara��es", pos, comp);
}
