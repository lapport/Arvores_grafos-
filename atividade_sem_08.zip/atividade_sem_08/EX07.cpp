#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 7 � Verifica��o de Contato

Um sistema precisa validar rapidamente se um n�mero est� salvo na agenda.
Lista de contatos: [9991, 9992, 9993, 9994]

Verifique usando busca sequencial se o n�mero 9993 est� cadastrado.
*/

void buscaSequencial(int vetor[], int tam, int busca){
	for(int i = 0; i < tam; i++){
		if(vetor[i] == busca){
			printf("numero %d esta cadastrado", busca);
			return;
		}
	}
	printf("Numero n�o foi encontrado");
}

int main(){

	setlocale(LC_ALL, "Portuguese");
	
	int numeros[] = {9991, 9992, 9993, 9994};
	int tamanho = sizeof(numeros) / sizeof(numeros[0]);
	
	int busca = 9993;
	
	buscaSequencial(numeros, tamanho, busca);
	
}
