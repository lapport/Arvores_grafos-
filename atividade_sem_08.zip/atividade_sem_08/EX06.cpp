#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 6 � Relat�rio de Vendas

Um gerente precisa identificar quantas vendas foram realizadas com um valor espec�fico para
an�lise financeira.

Valores registrados: [100, 200, 150, 300, 200]

Utilize busca sequencial para:
� Encontrar todas as vendas de 200
� Informar as posi��es 
*/


int buscaSequencial(int vetor[], int tam, int valor){
	int contador = 0;
	for(int i = 0 ; i < tam; i++){
		if(vetor[i] == valor){
			printf("Valor encontrado na posi��o: %d \n", i);
			contador++;
		}
	}
	return contador;
}


int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int valores[] = {100, 200, 150, 300, 200};
	int tamanho = sizeof(valores) / sizeof(valores[0]);
	
	int busca_venda = 200;
	
	int qtd = buscaSequencial(valores, tamanho, busca_venda);
	
	if (qtd == 0){
		printf("Neunhum valor foi encontrado");
	}else{
		printf("O valor foi encontrado %d vezes", qtd);
	}
}
