#include<stdio.h>
#include<locale.h>

/*
Um sistema precisa localizar rapidamente a matr�cula de um aluno entre milhares de registros.

Dados desordenados de matr�culas: [20, 40, 50, 10, 30]

1. Ordene
2. Busque uma matr�cula informada usando busca bin�ria 
*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j - 1;
		}
		vetor[j + 1] = key;
	}
	printf("Vetor ordenado\n");
}


int buscaBinaria(int vetor[], int tam, int busca){
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		
		if(vetor[meio] == busca){
			printf("ACHOU\n");
			return meio;
		}
		
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
	printf("Valor n�o encontrado");
}




int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int matriculas[] = {20, 40, 50, 10, 30};
	int tamanho = sizeof(matriculas) / sizeof(matriculas[0]);
	int busca;
	printf("Matricula que deseja buscar: ");
	scanf("%d", &busca);
	
	ordenarVetor(matriculas, tamanho);
	
	int pos = buscaBinaria(matriculas, tamanho, busca);
	
	printf("Valor %d encontrado na posi��o %d", busca, pos);
	
}

