#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 30 � Sistema Completo de An�lise
Uma empresa quer analisar desempenho de algoritmos em seu sistema.
O programa deve:

1. Receber 20 n�meros
2. Exibir dados originais
3. Ordenar os dados
4. Permitir m�ltiplas buscas
5. Escolher tipo de busca
6. Exibir:

o Resultado
o Posi��o
o Compara��es
o Qual algoritmo foi mais eficiente

*/

void ordenarVetor(int vetor[], int tam){
	int i, j, key;
	for(i = 1; i < tam; i++){
		key = vetor[i];
		j = i - 1;
		
		while(j >= 0 && vetor[j] > key){
			vetor[j + 1] = vetor[j];
			j = j -1;
		}
		vetor[j + 1] = key;
	}
}

int buscaSequencial(int vetor[],int tam,int busca, int *comp){
	
	for(int i = 0; i < tam; i++){
		(*comp)++;
		if(vetor[i] == busca){
			return i;
		}
	}
	return -1;
}

int buscaBinaria(int vetor[], int tam, int busca, int *compb){
	ordenarVetor(vetor, tam);
	int esquerda = 0;
	int direita = tam - 1;
	
	while(esquerda <= direita){
		int meio = esquerda + (direita - esquerda) / 2;
		(*compb)++;
		if(vetor[meio] == busca){
			return meio;
		}
		if(vetor[meio] < busca){
			esquerda = meio + 1;
		}else{
			direita = meio - 1;
		}
	}
}

int main (){
	setlocale(LC_ALL, "Portuguese");
	
	int tamanho = 5; 
	
	int vetor[tamanho];
	int opc, busca;
	
	for(int i = 0; i < tamanho; i++){
		printf("Valor da posi�ao %d: ", i);
		scanf("%d", &vetor[i]);
	}
	
	printf("Valores digitados: ");
	for(int i = 0; i < tamanho; i++){
		printf("%d ", vetor[i]);
	}
	printf("\n");
	
	ordenarVetor(vetor, tamanho);
	do{
		printf("1 - Sequencial\n");
		printf("2 - Binaria\n");
		printf("3 - Comparar os 2\n");
		printf("0 - Sair");
	
		printf("\nEscolha uma op�ao: ");
		scanf("%d", &opc);
	
		if(opc == 1){
			int compSeq = 0;
			printf("digite a busca: ");
			scanf("%d", &busca);
			int posSeq = buscaSequencial(vetor, tamanho, busca, &compSeq);
			if(posSeq != -1){
				printf("Valor encontrado na posi�ao %d com %d compara�oes\n", posSeq, compSeq);
			}else{
				printf("Nao encontrado");
			}
		}
		if(opc == 2){
			int compBin = 0;
			printf("digite a busca: ");
			scanf("%d", &busca);
			int posBin = buscaBinaria(vetor, tamanho, busca, &compBin);
			if(posBin != -1){
				printf("Valor encontrado na posi�ao %d com %d compara�oes\n",posBin, compBin);				
			}else{
				printf("Nao encontrado");
			}

		}
		if(opc == 3){
			printf("digite a busca: ");
			scanf("%d", &busca);
			int compSeq = 0;
			int compBin = 0;
			int posSeq = buscaSequencial(vetor, tamanho, busca, &compSeq);
			int posBin = buscaBinaria(vetor, tamanho, busca, &compBin);
			
			if(posBin != -1){
				printf("Valor encontrado com sequencial na posi�ao %d com %d compara�oes\n",posBin, compBin);				
			}else{
				printf("Nao encontrado\n");
			}
			
			if(posSeq != -1){
				printf("Valor encontrado com binaria na posi�ao %d com %d compara�oes\n", posSeq, compSeq);
			}else{
				printf("Nao encontrado");
			}
			
			if(compSeq > compBin){
				printf("A busca binaria (%d compara�oes) foi melhor que a sequencial (%d compara�oes)\n", compBin, compSeq);
			}else{
				printf("A busca sequencial (%d compara�oes) foi melhor que a vinaria (%d compara�oes)\n", compSeq, compBin);
			}
			
		}
	}while(opc != 0);
	printf("FINALIZADO");
}

