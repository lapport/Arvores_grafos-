#include<stdio.h>
#include<locale.h>

/*
Exerc�cio 8 � Monitoramento de Acessos

Um sistema de seguran�a registra acessos por ID e precisa identificar padr�es de uso.
Registros: [1, 2, 3, 2, 4, 2]

Utilize busca sequencial para:
� Contar quantas vezes o ID 2 acessou o sistema
*/


int buscaSequencial(int vetor[], int tam, int busca){
	int contador = 0;
	for(int i = 0; i < tam; i++){
		if(vetor[i] == busca){
			contador++;
		}
	}
	return contador;	
}

int main(){
	setlocale(LC_ALL, "Portuguese");
	
	int id[] = {1, 2, 3, 2, 4, 2};
	int tamanho = sizeof(id) / sizeof(id[0]);
	
	int busca_id = 2;
	
	int qtd = buscaSequencial(id, tamanho, busca_id);
	
	printf("O id %d acessou %d vezes o sisetema", busca_id, qtd);
}
