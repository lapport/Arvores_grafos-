#include<stdio.h>

/*
Exerc�cio 1 � Chamada Automatizada

Uma aplica��o de controle de presen�a registra automaticamente as matr�culas dos alunos que
responderam � chamada no sistema:  [101, 102, 103, 104, 105]

O professor deseja saber se o aluno de matr�cula 103 foi registrado.

Verifique usando busca sequencial:
� Se o aluno est� presente
� A posi��o no vetor
� Quantas compara��es foram realizadas 
*/


int buscaSequencial(int vetor[], int tam, int matricula, int*comparacoes){
	for(int i = 0; i < tam; i++){
		(*comparacoes)++;
		if(vetor[i] == matricula){
			printf("Aluno encontrado");
			return i;
		}
	}
	printf("O aluno nao esta matriculado");
	return -1;
}


int main(){
	int dados[] = {101, 102, 103, 104, 105};
	int tamanho = sizeof(dados) / sizeof(dados[0]);
	
	int comparacoes = 0;
	int matricula = 103;
	
	int posicao = buscaSequencial(dados, tamanho, matricula, &comparacoes);
	
	printf("O aluno de matricula %d esta na posi�ao %d do vetor ",matricula, posicao);
	printf("\nForam feitas %d comparacoes", comparacoes);
}
